package com.snhu.sslserver;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{
	//our hash method
	public static String calculateHash(String name) throws NoSuchAlgorithmException{
		
		
    	MessageDigest md = MessageDigest.getInstance("SHA-256");
    	byte[] hash = md.digest(name.getBytes(StandardCharsets.UTF_8));
    	BigInteger hex = new BigInteger(1, hash);
    	
   
    	StringBuilder checksum = new StringBuilder(hex.toString(16));
    	while (checksum.length() < 32) {
    		checksum.insert(0,'0');
    	} 
    	return checksum.toString();
	}
   
	
	@RequestMapping("/hash")
    public String myHash() throws Exception{
	
    	String data = "Jhon Doe";       
    
    	String hash = calculateHash(data);
        return "<p>data: "+ data + ": Check Sum Value: " + hash;
    }
}
